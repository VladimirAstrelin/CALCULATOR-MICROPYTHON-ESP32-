#---------------------------------------------------------------
# | File        :   key.py                                      
# | Author      :   Waveshare team                              
# | Function    :   Press Boot key to change RGB led status
#---------------------------------------------------------------
# | This version:   V1.0                                        
# | Date        :   2023-07-01                                  
# | Info        :   Basic version                               
#---------------------------------------------------------------

import machine
import neopixel
import time
import random

# LED strip data input pin
led_pin = machine.Pin(38)

# WS2812 light strip object
num_leds = 1
leds = neopixel.NeoPixel(led_pin, num_leds)

# Random color generator
def random_color():
    return (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))

# Initialize button
button = machine.Pin(0, machine.Pin.IN, machine.Pin.PULL_UP)

# Record the previous button state
prev_button_state = button.value()

# Loop to change the color
while True:
    # Check if button state has changed
    if button.value() == 0 and prev_button_state == 1:
        # Randomly select a color
        color = random_color()

        # Traverse each light and set color
        for i in range(num_leds):
            leds[i] = color

        # Update the light strip
        leds.write()

    # Record the current button state
    prev_button_state = button.value()

    # Delay for a period of time
    time.sleep(0.01)
