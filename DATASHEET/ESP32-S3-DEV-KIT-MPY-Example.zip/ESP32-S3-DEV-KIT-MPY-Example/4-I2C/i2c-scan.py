#---------------------------------------------------------------
# | File        :   i2c-scan.py                               
# | Author      :   Waveshare team                              
# | Function    :   i2c scan
# | Info        :   i2c test code                          
#---------------------------------------------------------------
# | This version:   V1.0                                        
# | Date        :   2023-07-10                                  
# | Info        :   Basic version                               
#---------------------------------------------------------------
from machine import Pin, I2C

# create an I2C object with SCL on pin D9 and SDA on pin D8
bus = I2C(1, scl=Pin(40), sda=Pin(42), freq=400_000)

# scan the I2C bus for connected devices and print their addresses
print(bus.scan())



