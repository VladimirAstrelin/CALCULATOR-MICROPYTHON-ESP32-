#---------------------------------------------------------------
# | File        :   brightness.py                                      
# | Author      :   Waveshare team                              
# | Function    :   change RGB led brightness
#---------------------------------------------------------------
# | This version:   V1.0                                        
# | Date        :   2023-07-01                                  
# | Info        :   Basic version                               
#---------------------------------------------------------------

import machine
import neopixel
import time

# Set up the neopixel strip
np = neopixel.NeoPixel(machine.Pin(38), 1)

# Define a function to set the brightness of the LED
def set_brightness(brightness):
    # Make sure the brightness value is within the valid range
    brightness = min(max(brightness, 0), 255)

    # Set the brightness of the LED
    np[0] = (brightness, brightness, brightness)
    np.write()

# Test the LED by ramping up and down the brightness
for i in range(256):
    set_brightness(i)
    time.sleep(0.5)
for i in range(255, -1, -1):
    set_brightness(i)
    time.sleep(0.5)