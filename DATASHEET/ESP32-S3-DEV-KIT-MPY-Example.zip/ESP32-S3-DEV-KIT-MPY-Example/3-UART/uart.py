#---------------------------------------------------------------
# | File        :   uart.py                                    
# | Author      :   Waveshare team                              
# | Function    :   Communicate with UART1 (GPIO18, GPIO17) for data transmission and reception.                   
# | Info        :   uart test code                          
#---------------------------------------------------------------
# | This version:   V1.0                                        
# | Date        :   2023-07-01                                  
# | Info        :   Basic version                               
#---------------------------------------------------------------
from machine import UART
import time

uart1 = UART(1, 115200, rx=18,tx=17)
while True:
    uart1.write('Hello World!\r\n')
    while(uart1.any()):
        data = uart1.read()
        print(data)
    time.sleep_ms(1000)
    


