#---------------------------------------------------------------
# | File        :   adc.py                               
# | Author      :   Waveshare team                              
# | Function    :   read ADC1_0、ADC1_1、ADC1_2 voltage
# | Info        :   adc test code                          
#---------------------------------------------------------------
# | This version:   V1.0                                        
# | Date        :   2023-07-08                                  
# | Info        :   Basic version                               
#---------------------------------------------------------------
from machine import Pin, ADC
import time

# Initialize ADC objects for the USB and three other pins (A1, A2, and A3)
A1_ADC = ADC(Pin(1), atten=ADC.ATTN_11DB)
A2_ADC = ADC(Pin(2), atten=ADC.ATTN_11DB)
A3_ADC = ADC(Pin(3), atten=ADC.ATTN_11DB)


while True:
    print("/*********** ADC TEST ***********/")

    # Read the voltage from the GPIO1 pin and print it to the console
    ADC_VOL = A1_ADC.read_uv() / 1000.0 / 1000.0
    print("A1 VOL  = {:.2F}V".format(ADC_VOL))

    # Read the voltage from the GPIO2 pin and print it to the console
    ADC_VOL = A2_ADC.read_uv() / 1000.0 / 1000.0
    print("A2 VOL  = {:.2F}V".format(ADC_VOL))

    # Read the voltage from the GPIO3 pin and print it to the console
    ADC_VOL = A3_ADC.read_uv() / 1000.0 / 1000.0
    print("A3 VOL  = {:.2F}V".format(ADC_VOL))

    # Wait for 1 second before taking the next reading
    time.sleep_ms(1000)